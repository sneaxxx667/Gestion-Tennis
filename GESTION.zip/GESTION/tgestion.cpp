#include "tgestion.h"

tGestion::tGestion(const char* fichierComptes, const char* fichierHistorique)
{




}
