#ifndef TLECTEUR_H
#define TLECTEUR_H
#include "iostream"
#include "trs232.h"
#include"string.h"
using namespace std;


class tLecteur
{
    private:
        tRs232 PortSerie;
        void LireTrame(char* Trame);

    public:
        void LireNumero(char* Num);

};

#endif // TLECTEUR_H
