TEMPLATE = app
CONFIG += console c++11
CONFIG -= app_bundle
CONFIG -= qt

SOURCES += \
        main.cpp \
        rpi2_exp500_gpio.cpp \
        tcomptesmembres.cpp \
        tgestion.cpp \
        thistorique.cpp \
        tlecteur.cpp \
        tmateriel.cpp \
        trs232.cpp

HEADERS += \
    rpi2_exp500_gpio.h \
    tcomptesmembres.h \
    tgestion.h \
    thistorique.h \
    tlecteur.h \
    tmateriel.h \
    trs232.h
